import Note from "./Note.jsx";

const Notes = () => {
  return (
    <main className="w-[80%] mx-auto">
      <Note />
    </main>
  );
};

export default Notes;
